import json
import time
import threading
from pathlib import Path
from util import get_local_ip_and_broadcast
from discovery import Discovery
from messaging import Messaging

# === Configuración general ===
USER_ID = "usuario"  # puede cambiarse si lo quieres leer desde settings
SHARED_DIR = Path("shared")
SHARED_DIR.mkdir(parents=True, exist_ok=True)

# Crear .gitignore si no existe
GITIGNORE_FILE = SHARED_DIR / ".gitignore"
if not GITIGNORE_FILE.exists():
    GITIGNORE_FILE.write_text("*\n!.gitignore\n")

HISTORY_FILE = SHARED_DIR / "history.json"
PEERS_FILE = SHARED_DIR / "peers.json"
OUTBOX_FILE = SHARED_DIR / "outbox.json"
SCAN_FILE = SHARED_DIR / "scan_now.json"
SETTINGS_FILE = SHARED_DIR / "settings.json"

# === Leer nickname si existe en settings
def load_json(p: Path, default):
    try:
        if not p.exists() or p.stat().st_size == 0:
            p.write_text(json.dumps(default))
            return default
        return json.loads(p.read_text())
    except:
        return default

def save_json(p: Path, data):
    p.write_text(json.dumps(data))

# Leer nombre del usuario
settings = load_json(SETTINGS_FILE, {"nickname": USER_ID})
USER_ID = settings.get("nickname", USER_ID)

# === Callbacks de red ===
def on_message(sender, message):
    history = load_json(HISTORY_FILE, {})
    history.setdefault(sender, []).append(("peer", message))
    save_json(HISTORY_FILE, history)
    print(f"[MSG] {sender}: {message}")

def on_file(sender, filepath):
    history = load_json(HISTORY_FILE, {})
    history.setdefault(sender, []).append(("file", filepath))
    save_json(HISTORY_FILE, history)
    print(f"[FILE] {sender} envió {filepath}")

# === Motor principal ===
def run_chat_engine():
    print(f"[ENGINE] Iniciando como '{USER_ID}'...")

    disc = Discovery(USER_ID)
    msg = Messaging(USER_ID, on_message=on_message, on_file=on_file, udp_sock=disc.sock)

    # === Bucle de descubrimiento automático + forzado
    def discovery_loop():
        while True:
            do_scan = True

            if SCAN_FILE.exists():
                try:
                    trigger = json.loads(SCAN_FILE.read_text())
                    if trigger.get("scan") is True:
                        do_scan = True
                        SCAN_FILE.unlink()
                except:
                    pass

            if do_scan:
                peers = disc.search_peers()
                msg.update_peers(peers)
                save_json(PEERS_FILE, peers)
                print(f"[ENGINE] Vecinos actualizados: {list(peers.keys())}")

            time.sleep(10)

    # === Bucle para enviar mensajes desde la interfaz
    def outbox_loop():
        while True:
            outbox = load_json(OUTBOX_FILE, [])
            if outbox:
                new_outbox = []
                for entry in outbox:
                    peer = entry.get("to")
                    message = entry.get("message")
                    if peer and message:
                        result = msg.send_message(peer, message)
                        print(f"[OUTBOX] → {peer}: {'OK' if result else 'FAIL'}")
                save_json(OUTBOX_FILE, new_outbox)
            time.sleep(1)

    threading.Thread(target=discovery_loop, daemon=True).start()
    threading.Thread(target=outbox_loop, daemon=True).start()

    # Bucle principal
    while True:
        time.sleep(1)

if __name__ == "__main__":
    run_chat_engine()
